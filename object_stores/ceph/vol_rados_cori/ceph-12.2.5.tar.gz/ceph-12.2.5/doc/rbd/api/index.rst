========================
 Ceph Block Device APIs
========================

.. toctree::
   :maxdepth: 2

   librados (Python) <librbdpy>
